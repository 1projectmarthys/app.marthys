<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak Form Internal Transfer - {{ $transfer->nomor_dokumen }}</title>
    <style>
        @media print {
            @page {
                size: A4 landscape;
                margin: 8mm 10mm;
            }
            body { margin: 0; }
            .no-print { display: none !important; }
        }

        * { box-sizing: border-box; }
        body {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 11pt;
            color: #000;
            margin: 20px;
        }

        .sheet { width: 100%; max-width: 1000px; margin: 0 auto; }

        /* ===== HEADER ===== */
        .top { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
        .top td { vertical-align: middle; padding: 0; }
        .brand img { height: 46px; width: auto; }
        .brand-fallback { font-weight: bold; font-size: 15pt; }
        .brand-fallback small { display: block; font-size: 7pt; letter-spacing: 2px; background: #f0a500; padding: 1px 4px; width: max-content; }
        .doc-title { text-align: center; font-size: 20pt; font-weight: bold; line-height: 1.1; }

        .meta { border-collapse: collapse; font-size: 10.5pt; width: 320px; }
        .meta td { padding: 1px 4px; white-space: nowrap; }
        .meta td:first-child { width: 110px; }

        /* ===== REKENING ===== */
        .rek-wrap { width: 100%; border-collapse: collapse; margin-top: 6px; }
        .rek-wrap > td { width: 50%; vertical-align: top; padding: 0; }
        .rek-wrap > td:first-child { padding-right: 8px; }

        .rek { width: 100%; border: 1px solid #000; border-collapse: collapse; font-size: 10.5pt; }
        .rek caption {
            border: 1px solid #000; border-bottom: none;
            font-weight: bold; text-align: center; padding: 4px; background: #fff;
        }
        .rek td { border-top: 1px solid #000; padding: 4px 8px; }
        .rek td:first-child { width: 40%; }

        /* ===== JUMLAH ===== */
        .jumlah { width: 100%; border-collapse: collapse; margin-top: 14px; font-size: 11pt; }
        .jumlah td { border: 1px solid #000; padding: 5px 8px; }
        .jumlah td.lbl { width: 150px; font-weight: normal; }

        /* ===== BAWAH: JENIS + NOTE/TTD ===== */
        .bottom { width: 100%; border-collapse: collapse; margin-top: 16px; }
        .bottom > td { vertical-align: top; padding: 0; }
        .bottom > td.left { width: 38%; padding-right: 14px; }

        .jenis-title { margin-bottom: 6px; }
        .jenis-item { margin: 5px 0; }
        .cb {
            display: inline-block; width: 12px; height: 12px;
            border: 1px solid #000; margin-right: 8px; vertical-align: -1px; text-align: center;
            line-height: 12px; font-size: 10px;
        }

        .note-line { margin-bottom: 6px; }

        .sign { width: 100%; border-collapse: collapse; font-size: 10pt; }
        .sign th, .sign td { border: 1px solid #000; text-align: center; padding: 4px; }
        .sign .space { height: 56px; }

        .print-btn {
            display: inline-block; margin-bottom: 16px; padding: 8px 16px;
            background: #1a56db; color: #fff; border: none; border-radius: 6px;
            font-size: 12px; cursor: pointer; text-decoration: none;
        }
    </style>
</head>
<body>
    <button class="print-btn no-print" onclick="window.print()">&#128424; Cetak</button>

    <div class="sheet">
        {{-- ===== HEADER ===== --}}
        <table class="top">
            <tr>
                <td class="brand" style="width:220px;">
                    <img src="{{ asset('image/logo.png') }}" alt="marthys"
                         onerror="this.style.display='none';document.getElementById('brandfb').style.display='block';">
                    <div id="brandfb" class="brand-fallback" style="display:none;">
                        marthys<small>ORTHOPAEDICS</small>
                    </div>
                </td>
                <td class="doc-title">FORM INTERNAL<br>TRANSFER</td>
                <td style="width:320px;">
                    <table class="meta">
                        <tr><td>Nomor</td><td>: {{ $transfer->nomor_dokumen }}</td></tr>
                        <tr><td>Tanggal</td><td>: {{ \Carbon\Carbon::parse($transfer->tanggal)->format('d/m/Y') }}</td></tr>
                        <tr><td>Rencana Bayar</td><td>: {{ \Carbon\Carbon::parse($transfer->rencana_bayar)->format('d/m/Y') }}</td></tr>
                    </table>
                </td>
            </tr>
        </table>

        {{-- ===== REKENING PENGIRIM & PENERIMA ===== --}}
        <table class="rek-wrap">
            <tr>
                <td>
                    <table class="rek">
                        <caption>Rekening Pengirim</caption>
                        <tr><td>Dari Bank</td><td>: {{ $transfer->dari_bank }}</td></tr>
                        <tr><td>No. Rekening</td><td>: {{ $transfer->norek_pengirim }}</td></tr>
                        <tr><td>Atas Nama</td><td>: {{ $transfer->atasnama_pengirim }}</td></tr>
                    </table>
                </td>
                <td>
                    <table class="rek">
                        <caption>Rekening Penerima</caption>
                        <tr><td>Ke Bank</td><td>: {{ $transfer->ke_bank }}</td></tr>
                        <tr><td>No. Rekening</td><td>: {{ $transfer->norek_penerima }}</td></tr>
                        <tr><td>Atas Nama</td><td>: {{ $transfer->atasnama_penerima }}</td></tr>
                    </table>
                </td>
            </tr>
        </table>

        {{-- ===== JUMLAH TRANSFER & TERBILANG ===== --}}
        <table class="jumlah">
            <tr>
                <td class="lbl">Jumlah Transfer</td>
                <td>: Rp {{ number_format($transfer->jumlah_transfer, 0, ',', '.') }}</td>
            </tr>
            <tr>
                <td class="lbl">Terbilang</td>
                <td>: {{ $transfer->terbilang }}</td>
            </tr>
        </table>

        {{-- ===== JENIS TRANSFER + NOTE/TTD ===== --}}
        <table class="bottom">
            <tr>
                <td class="left">
                    <div class="jenis-title">Jenis Transfer :</div>
                    @foreach(\App\Models\InternalTransfer::jenisTransferOptions() as $key => $label)
                        @if($key === 'lainnya')
                            <div class="jenis-item">
                                <span class="cb">{{ $transfer->jenis_transfer === 'lainnya' ? '&#10003;' : '' }}</span>
                                Lainnya :
                                <span style="border-bottom:1px solid #000; display:inline-block; min-width:140px;">
                                    {{ $transfer->jenis_transfer === 'lainnya' ? $transfer->jenis_transfer_lainnya : '' }}
                                </span>
                            </div>
                        @else
                            <div class="jenis-item">
                                <span class="cb">{!! $transfer->jenis_transfer === $key ? '&#10003;' : '' !!}</span>
                                {{ $label }}
                            </div>
                        @endif
                    @endforeach
                </td>
                <td>
                    <div class="note-line">Note : {{ $transfer->note }}</div>
                    <table class="sign">
                        <tr>
                            <th>Diajukan</th>
                            <th>Diverifikasi</th>
                            <th>Diperiksa</th>
                            <th colspan="2">Disetujui</th>
                        </tr>
                        <tr>
                            <td class="space"></td>
                            <td class="space"></td>
                            <td class="space"></td>
                            <td class="space"></td>
                            <td class="space"></td>
                        </tr>
                        <tr>
                            <td>Finance</td>
                            <td>Accounting</td>
                            <td>Manager FA</td>
                            <td>Wakil Direktur</td>
                            <td>Direktur Utama</td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </div>
</body>
</html>
